Hello <?php echo e($user['first_name']); ?> <?php echo e($user['last_name']); ?>,

Your new password is:<?php echo e($user['password']); ?>

kindly login in with the password and change password on successful login:
<?php echo e(route('login')); ?>

<?php /**PATH /home/vagrant/myschool/tagapi/resources/views/emails/forget_password.blade.php ENDPATH**/ ?>